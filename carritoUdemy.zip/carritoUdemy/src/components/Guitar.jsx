import { useEffect, useRef, useState } from 'react'
import PropTypes from 'prop-types'

const MIN_ZOOM = 1
const MAX_ZOOM = 3
const ZOOM_STEP = 0.25
const BASE_IMAGE_WIDTH_REM = 10

export default function Guitar({guitar, addToCart}) {

    const { name, image, images, description, stock, price } = guitar
    const modalImages = Array.isArray(images) && images.length > 0 ? images : [image]


    const [quantity, setQuantity] = useState(1)
    const [isModalOpen, setIsModalOpen] = useState(false)
    const [selectedImage, setSelectedImage] = useState(modalImages[0])
    const [zoomLevel, setZoomLevel] = useState(MIN_ZOOM)
    const imageFrameRef = useRef(null)

    const handleAddToCart = () => {
        if (globalThis.confirm(`¿Agregar ${quantity} ${name}(s) al carrito?`)) {
            addToCart({...guitar, quantity})
        }
    }

    const openModal = () => {
        setSelectedImage(modalImages[0])
        setZoomLevel(MIN_ZOOM)
        setIsModalOpen(true)
    }

    const closeModal = () => {
        setIsModalOpen(false)
        setZoomLevel(MIN_ZOOM)
    }

    const handleSelectImage = (imageName) => {
        setSelectedImage(imageName)
        setZoomLevel(MIN_ZOOM)
    }

    const zoomInImage = () => setZoomLevel((prev) => Math.min(prev + ZOOM_STEP, MAX_ZOOM))
    const zoomOutImage = () => setZoomLevel((prev) => Math.max(prev - ZOOM_STEP, MIN_ZOOM))

    useEffect(() => {
        const frame = imageFrameRef.current

        if (!frame || !isModalOpen) {
            return
        }

        const nextLeft = Math.max(0, (frame.scrollWidth - frame.clientWidth) / 2)
        const nextTop = Math.max(0, (frame.scrollHeight - frame.clientHeight) / 2)

        frame.scrollTo({
            left: nextLeft,
            top: nextTop,
            behavior: 'auto'
        })
    }, [isModalOpen, selectedImage, zoomLevel])

    return (
        <div className="col-md-6 col-lg-4 my-4 d-flex">
            <div className="guitar-card row align-items-center">
            <div className="col-4 guitar-card-media">
                <button
                    type="button"
                    className="guitar-image-trigger"
                    onClick={openModal}
                    aria-label={`Ver detalle de ${name}`}
                >
                    <img className="img-fluid guitar-card-image" src={`/img/${image}.jpg`} alt={`imagen de ${name}`} />
                </button>
            </div>
            <div className="col-8 guitar-card-content">
                <h3 className="text-black fs-4 fw-bold text-uppercase">{name}</h3>
                <p className="guitar-card-description">{description}</p>
                <div className="mb-4">                    
                    <div className="availability-row">
                        {stock > 0 ? (
                            <>
                                <div className="available-label fw-bold">Disponibles ({stock})</div>
                                <div className="availability-select-wrap">
                                    <select 
                                        className="form-select form-select-sm availability-select" 
                                        value={quantity} 
                                        onChange={(e) => setQuantity(Number.parseInt(e.target.value, 10))}
                                    >
                                        {Array.from({length: stock}, (_, i) => (
                                            <option key={i + 1} value={i + 1}>{i + 1}</option>
                                        ))}
                                    </select>
                                </div>
                            </>
                        ) : (
                            <div className="unavailable-label fw-bold">No Disponible</div>
                        )}
                    </div>
                </div>
                {stock <= 5 && stock > 0 && <span className="low-stock-note">Quedan pocas unidades, haz tu pedido</span>}
                <p className="fw-black text-primary fs-3">${price}</p>
                <button 
                    type="button"
                    className="btn btn-dark w-100 guitar-btn"
                    onClick={handleAddToCart}
                    disabled={stock === 0}
                >Agregar al Carrito</button>
            </div>
            </div>

            {isModalOpen && (
                <div className="guitar-modal-backdrop">
                    <dialog
                        className="guitar-modal"
                        open
                        aria-label={`Detalle de ${name}`}
                    >
                        <div className="guitar-modal-header">
                            <h3 className="guitar-modal-title">{name}</h3>
                            <button
                                type="button"
                                className="guitar-modal-close"
                                onClick={closeModal}
                                aria-label="Cerrar detalle"
                            >
                                x
                            </button>
                        </div>

                        <div className="guitar-modal-image-frame" ref={imageFrameRef}>
                            <div className="guitar-modal-image-canvas">
                                <img
                                    className="guitar-modal-image"
                                    src={`/img/${selectedImage}.jpg`}
                                    alt={`detalle de ${name}`}
                                    style={{ width: `${BASE_IMAGE_WIDTH_REM * zoomLevel}rem` }}
                                />
                            </div>
                        </div>

                        <div className="guitar-modal-image-tools">
                            <div className="guitar-modal-zoom-actions">
                                <button
                                    type="button"
                                    className="guitar-modal-zoom-btn"
                                    onClick={zoomOutImage}
                                    disabled={zoomLevel <= MIN_ZOOM}
                                    aria-label="Reducir imagen"
                                >
                                    -
                                </button>
                                <button
                                    type="button"
                                    className="guitar-modal-zoom-btn"
                                    onClick={zoomInImage}
                                    disabled={zoomLevel >= MAX_ZOOM}
                                    aria-label="Ampliar imagen"
                                >
                                    +
                                </button>
                            </div>
                        </div>

                        {modalImages.length > 1 && (
                            <div className="guitar-modal-thumbs" aria-label="Galeria de imagenes">
                                {modalImages.map((imageName) => (
                                    <button
                                        key={imageName}
                                        type="button"
                                        className={`guitar-modal-thumb ${selectedImage === imageName ? 'is-active' : ''}`}
                                        onClick={() => handleSelectImage(imageName)}
                                        aria-label={`Ver imagen ${imageName}`}
                                    >
                                        <img src={`/img/${imageName}.jpg`} alt={`miniatura de ${name}`} />
                                    </button>
                                ))}
                            </div>
                        )}

                        <p className="guitar-modal-description">{description}</p>
                        <p className="guitar-modal-meta">Precio: <span className="fw-bold text-primary">${price}</span></p>
                        <p className="guitar-modal-meta">Stock: {stock > 0 ? `Disponible (${stock})` : 'No disponible'}</p>

                        <div className="guitar-modal-footer">
                            <button
                                type="button"
                                className="guitar-modal-action"
                                onClick={closeModal}
                            >
                                Cerrar
                            </button>
                        </div>
                    </dialog>
                </div>
            )}
        </div>
    )
}

Guitar.propTypes = {
    guitar: PropTypes.shape({
        name: PropTypes.string.isRequired,
        image: PropTypes.string.isRequired,
        images: PropTypes.arrayOf(PropTypes.string),
        description: PropTypes.string.isRequired,
        stock: PropTypes.number.isRequired,
        price: PropTypes.number.isRequired
    }).isRequired,
    addToCart: PropTypes.func.isRequired
}
